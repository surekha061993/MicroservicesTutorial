package com.cjc;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class DepartmentController {
	@Autowired
	private StudentServiceProxy proxy;

	@GetMapping("/dept-service/{deptname}/student-service/{rollno}")
	public Department getStudentByDepartment(@PathVariable String deptname, @PathVariable int rollno) {
		
		Map<String,Integer> uriVariables=new HashMap<String, Integer>();
		uriVariables.put("rollno",rollno);
		ResponseEntity<Department> response=new RestTemplate().getForEntity("http://localhost:8000/student-service/{rollno}", Department.class, uriVariables);
		
		Department dept=response.getBody();
		return new Department(deptname, rollno,dept.getName(), dept.getPort());
	}
	
	@GetMapping("/dept-service-proxy/{deptname}/student-service/{rollno}")
	public Department getStudentByDepartmentFeignProxy(@PathVariable String deptname, @PathVariable int rollno) {

		Department dept=proxy.getStudentData(rollno);
		System.out.println(dept);
		return new Department(deptname, rollno,dept.getName(), dept.getPort());
	}
}
