insert into student(rollno,name) values(1,'cjc')
insert into student(rollno,name) values(2,'akurdi')
